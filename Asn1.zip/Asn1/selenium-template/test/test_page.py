from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.keys import Keys

from contextlib import contextmanager
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support.expected_conditions import staleness_of

from pathlib import Path
import os


def construct_headless_chrome_driver():
    options = Options()
    options.add_argument("--disable-extensions")
    options.add_argument("--disable-gpu")
    options.add_argument("--no-sandbox")
    options.add_argument("--headless")
    return webdriver.Chrome(options=options)


def get_landing_page_url():
    test_dir = os.getcwd()
    index_path = os.path.join(test_dir, "..", "page", "index.html")
    index_uri = Path(index_path).as_uri()
    return index_uri


# As demonstrated in the linked web page from the course assignment
@contextmanager
def wait_for_page_load(driver, timeout=30):
    old_page = driver.find_element_by_tag_name('html')
    yield
    WebDriverWait(driver, timeout).until( staleness_of(old_page) )


def test_nonsecret_scenario():
    landing_page = get_landing_page_url()
    driver = construct_headless_chrome_driver()

    driver.get(landing_page)
    element_name = driver.find_element_by_name("preferredname")
    element_name.clear()
    element_name.send_keys("Richard")
    
    element_food = driver.find_element_by_id("food")
    element_food.clear()
    element_food.send_keys("hamburger")

    
    element_secret = driver.find_element_by_id("secret")
    element_secret.clear()
    element_secret.send_keys("itisnotsecret")
    
    driver.find_element_by_id("submit").click()
    wait_for_page_load(driver)
    
    assert "Richard" in driver.page_source
    assert "hamburger" in driver.page_source
   
    try:
    	driver.find_element_by_id("secretButton")
    except Exception: assert True
    else:assert False
    
    driver.close()
    driver.quit()
    
def test_secret_scenario():
    landing_page = get_landing_page_url()
    driver = construct_headless_chrome_driver()
    
    driver.get(landing_page)
    element_name = driver.find_element_by_name("preferredname")
    element_name.clear()
    element_name.send_keys("Zora")
    
    element_food = driver.find_element_by_id("food")
    element_food.clear()
    element_food.send_keys("tomato")

    
    element_secret = driver.find_element_by_id("secret")
    element_secret.clear()
    element_secret.send_keys("magic")
    #print("before first click"+driver.current_url)
    driver.find_element_by_id("submit").click()
    wait_for_page_load(driver)
    #print("after click"+driver.current_url)
    
    assert "Zora" in driver.page_source
    assert "tomato" in driver.page_source
    try:
    	driver.find_element_by_id("secretButton")
    except Exception: assert False
    else: 
    	assert True
    	
    #print("before first click"+driver.current_url)

    driver.find_element_by_id("secretButton").click()
    
    wait = WebDriverWait(driver,10,0.5)
    wait.until(lambda driver:driver.title == "SECRET Simple Web Page" )
    
    #print("after click"+driver.current_url)
    
    assert "SECRET Simple Web Page" in driver.title
    assert "Zora" in driver.page_source
    assert "magic" in driver.page_source
    # You can place additional test code here to drive this one test
    
    driver.close()
    driver.quit()
    
    
def test_secret_scenario_another_secret():
    landing_page = get_landing_page_url()
    driver = construct_headless_chrome_driver()
    
    driver.get(landing_page)
    element_name = driver.find_element_by_name("preferredname")
    element_name.clear()
    element_name.send_keys("Zora2")
    
    element_food = driver.find_element_by_id("food")
    element_food.clear()
    element_food.send_keys("tomato2")

    
    element_secret = driver.find_element_by_id("secret")
    element_secret.clear()
    element_secret.send_keys("abracadabra")
    #print("before first click"+driver.current_url)
    driver.find_element_by_id("submit").click()
    wait_for_page_load(driver)
    #print("after click"+driver.current_url)
    
    assert "Zora2" in driver.page_source
    assert "tomato2" in driver.page_source
    try:
    	driver.find_element_by_id("secretButton")
    except Exception: assert False
    else: 
    	assert True
    	
    	
    	
    #print("before first click"+driver.current_url)

    driver.find_element_by_id("secretButton").click()
    
    wait = WebDriverWait(driver,10,0.5)
    wait.until(lambda driver:driver.title == "SECRET Simple Web Page" )
    
    #print("after click"+driver.current_url)
    
    assert "SECRET Simple Web Page" in driver.title
    assert "Zora2" in driver.page_source
    assert "abracadabra" in driver.page_source
    # You can place additional test code here to drive this one test
    
    driver.close()
    driver.quit()
    

