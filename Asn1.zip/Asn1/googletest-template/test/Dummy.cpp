#include "gtest/gtest.h"
#include "gmock/gmock.h"

#include "Parallelogram.h"

using namespace testing;
using namespace shapes;

// class ParallelogramTests: public ::testing::Test {
//     protected:
//     Parallelogram parallelogram(Side(3),Side(5),Angle(30.0));
// };

// ------------ Failure test case -------------------

TEST (ParallelogramTests, setgetPerimeterFail){
    Parallelogram test_parallelogram(Side(3),Side(5),Angle(30.0));
    EXPECT_EQ(16,test_parallelogram.getPerimeter()) << "ERROR MESSAGE: It doesn't meet the expected result. Need using 2 * (hypotenuse + base) ";
}

TEST (ParallelogramTests, setgetAreaFail){
    Parallelogram test_parallelogram(Side(3),Side(5),Angle(30.0));
    EXPECT_EQ(7.5,test_parallelogram.getArea()) << "ERROR MESSAGE: It doesn't meet the expected result. Need using hypotenuse * sin(interior) * base ";
}


TEST (ParallelogramTests, setgetKindFail){
    Parallelogram test_parallelogram(Side(3),Side(5),Angle(30.0));
    EXPECT_EQ(Parallelogram::Kind::SQUARE,test_parallelogram.getKind())<< "ERROR MESSAGE: It doesn't meet the square requirment ";
}

// ------------ Pass test case -------------------

TEST (ParallelogramTests, setgetPerimeterPass){
    Parallelogram test_parallelogram(Side(5),Side(5),Angle(90.0));
    EXPECT_EQ(20,test_parallelogram.getPerimeter()) << "ERROR MESSAGE: It doesn't meet the expected result";
}

TEST (ParallelogramTests, setgetAreaPass){
    Parallelogram test_parallelogram(Side(5),Side(5),Angle(90.0));
    EXPECT_EQ(25,test_parallelogram.getArea())<< "ERROR MESSAGE: It doesn't meet the expected result.";
}

TEST (ParallelogramTests, setgetKindPass){
    Parallelogram test_parallelogram(Side(5),Side(5),Angle(90.0));
    EXPECT_EQ(Parallelogram::Kind::RECTANGLE,test_parallelogram.getKind()) << "ERROR MESSAGE: It doesn't meet the rectangle requirment ";
}

