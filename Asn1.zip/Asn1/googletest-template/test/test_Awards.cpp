#include "gtest/gtest.h"
#include "gmock/gmock.h"

#include "Awards.h"

using namespace testing;
using namespace awards;
using namespace std;


class RankListStub : public RankList{
    public: 
        MOCK_METHOD(string, getNext,(),(override));
};

class MockAwardCeremonyAction : public AwardCeremonyActions{
    public:
        MOCK_METHOD(void,playAnthem,());
        MOCK_METHOD(void,awardBronze,(string recipients),(override));
        MOCK_METHOD(void,awardSilver,(string recipients),(override));
        MOCK_METHOD(void,awardGold,(string recipients),(override));
        MOCK_METHOD(void,turnOffTheLightsAndGoHome,(),(override));
};
// source: https://google.github.io/googletest/gmock_cook_book.html

TEST (AwardsTests, performAwardCeremonyTest){
    RankListStub tempRankListRecipients;
    //The getNext() method of RankList should be called three times, 
    EXPECT_CALL(tempRankListRecipients,getNext())
        .Times(3)
        //names returned should be passed to awardBronze(), awardSilver(), and awardGold() in the same order
        .WillOnce(Return("Bronze"))
        .WillOnce(Return("Silver"))
        .WillOnce(Return("Gold"));

        MockAwardCeremonyAction mocktemp;
        EXPECT_CALL(mocktemp, playAnthem())
            .Times(1);
        EXPECT_CALL(mocktemp, awardBronze("Bronze"))
            .Times(1);
        EXPECT_CALL(mocktemp, awardSilver("Silver"))
            .Times(1);
        EXPECT_CALL(mocktemp, awardGold("Gold"))
            .Times(1);
        EXPECT_CALL(mocktemp, turnOffTheLightsAndGoHome())
            .Times(1);

        
        performAwardCeremony(tempRankListRecipients, mocktemp);
}
