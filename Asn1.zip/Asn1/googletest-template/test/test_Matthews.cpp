#include "gtest/gtest.h"
#include "gmock/gmock.h"

#include "Matthews.h"

using namespace testing;
using namespace sequence;

// ------------ Termination conditions case (0 == remainder) -------------------

TEST (MatthewsTests, ZeroMatthewsOutcomeTest){
    EXPECT_EQ(MatthewsOutcome::ZERO,checkMatthewsOutcome(6)) << "Result of Test case is ZERO MatthewsOutcome";
}
// ------------ Termination conditions case (-1 == number) -------------------

TEST (MatthewsTests, MinusOneCycleTest){
    EXPECT_EQ(MatthewsOutcome::MINUS_ONE_CYCLE,checkMatthewsOutcome(-1)) << "Result of Test case is MINUS_ONE_CYCLE MatthewsOutcome";
}
// ------------ Termination conditions case (-2 == number || -4 == number) -------------------

TEST (MatthewsTests, MinusTwoCycleTest){
    EXPECT_EQ(MatthewsOutcome::MINUS_TWO_CYCLE, checkMatthewsOutcome(-2)) << "Result of Test case is MINUS_TWO_CYCLE MatthewsOutcome";
    EXPECT_EQ(MatthewsOutcome::MINUS_TWO_CYCLE, checkMatthewsOutcome(-4)) << "Result of Test case is MINUS_TWO_CYCLE MatthewsOutcome";
}
// ------------ continuation conditions case (1 == remainder) -------------------
TEST (MatthewsTests, remainderOneTest){
    EXPECT_EQ(MatthewsOutcome::ZERO, checkMatthewsOutcome(4))<< "Result of Test case through the [remainder = 1] statement";
    EXPECT_EQ(MatthewsOutcome::ZERO, checkMatthewsOutcome(1))<< "Result of Test case through the [remainder = 1] statement";

}
// ------------ continuation conditions case (else statement case) -------------------
TEST (MatthewsTests, remainderElseTest){
    EXPECT_EQ(MatthewsOutcome::ZERO, checkMatthewsOutcome(5)) << "Result of Test case through the else statement";
    EXPECT_EQ(MatthewsOutcome::ZERO, checkMatthewsOutcome(8)) << "Result of Test case through the else statement";
    EXPECT_EQ(MatthewsOutcome::ZERO, checkMatthewsOutcome(2)) << "Result of Test case through the else statement";
}