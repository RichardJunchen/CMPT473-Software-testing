#include "waypoints.h"
FUZZFACTORY_DSF_NEW(__afl_perf_dsf, 1 << 16, FUZZFACTORY_REDUCER_MAX, 0);
