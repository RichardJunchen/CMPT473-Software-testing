#include <stdint.h>
#include <stddef.h>
#include <cstring>
#include "fuzz.h"
#include "json.h"

int LLVMFuzzerTestOneInput(const uint8_t *Data, size_t Size) {
    
    json_value* value;
    value = json_parse((json_char*)Data, Size);
    json_value* t_value = malloc(sizeof(json_value)*(Size+1));
    memcpy(t_value, value, sizeof(json_value)*(Size));
    t_value[Size] = '\0'; 
    return 0; 
}