#ifdef FUZZ

extern "C" int LLVMFuzzerTestOneInput(const uint8_t *Data, size_t Size);

#endif