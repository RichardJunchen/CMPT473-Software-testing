
class ClassInDefaultPackage {
    public static final int CONST = 99;
}
