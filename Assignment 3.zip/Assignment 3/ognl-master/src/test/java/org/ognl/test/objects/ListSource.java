package org.ognl.test.objects;

/**
 *
 */
public interface ListSource {

    public int getTotal();

    public Object addValue(Object value);

    public Object getName();
}
