package org.ognl.test.objects;

/**
 *
 */
public class TestInherited2 implements Inherited {

    public String getMyString()
    {
        return "inherited2";
    }
}
