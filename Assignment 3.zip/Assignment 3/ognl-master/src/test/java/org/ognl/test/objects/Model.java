package org.ognl.test.objects;

/**
 *
 */
public class Model {

    public int getOptionCount()
    {
        return 1;
    }
}
