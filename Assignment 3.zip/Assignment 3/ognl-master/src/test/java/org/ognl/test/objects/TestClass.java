package org.ognl.test.objects;

/**
 *
 */
public abstract class TestClass {

}
