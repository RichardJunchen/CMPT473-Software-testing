package org.ognl.test.objects;

/**
 *
 */
public class Copy {

    public int size()
    {
        return 1;
    }
}
