package org.ognl.test.objects;

import java.util.List;

/**
 *
 */
public interface IContentProvider {

    public List getElements();
}
