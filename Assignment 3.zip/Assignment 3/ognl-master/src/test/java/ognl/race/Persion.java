package ognl.race;

public class Persion extends Base{
    private String name = "abc";


    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
