package ognl.race;

/**
 *
 */
public class Base {
    private Boolean yn = true;
    public Boolean getYn() {
        return yn;
    }

    public void setYn(Boolean yn) {
        this.yn = yn;
    }
}
