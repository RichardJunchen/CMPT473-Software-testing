from mako import runtime, filters, cache
UNDEFINED = runtime.UNDEFINED
STOP_RENDERING = runtime.STOP_RENDERING
__M_dict_builtin = dict
__M_locals_builtin = locals
_magic_number = 10
_modified_time = 1646898524.772499
_enable_loop = True
_template_filename = '/home/vagrant/Desktop/a2/zzzeek-mako-12819efda61b/test/templates/chs_utf8.html'
_template_uri = 'chs_utf8.html'
_source_encoding = 'utf-8'
_exports = ['welcome_buffered', 'welcome']


def render_body(context,**pageargs):
    __M_caller = context.caller_stack._push_frame()
    try:
        __M_locals = __M_dict_builtin(pageargs=pageargs)
        def welcome_buffered(who,place='\xe5\x8c\x97\xe4\xba\xac'):
            return render_welcome_buffered(context._locals(__M_locals),who,place)
        def welcome(who,place='\xe5\x8c\x97\xe4\xba\xac'):
            return render_welcome(context._locals(__M_locals),who,place)
        name = context.get('name', UNDEFINED)
        __M_writer = context.writer()

        msg = '新中国的主席'
        
        
        __M_locals_builtin_stored = __M_locals_builtin()
        __M_locals.update(__M_dict_builtin([(__M_key, __M_locals_builtin_stored[__M_key]) for __M_key in ['msg'] if __M_key in __M_locals_builtin_stored]))
        __M_writer('\n\n')
        __M_writer('\n\n')
        __M_writer('\n\n')
        __M_writer(name)
        __M_writer(' \xe6\x98\xaf ')
        __M_writer(msg)
        __M_writer('<br/>\n')
        __M_writer(welcome('你'))
        __M_writer('\n')
        __M_writer(welcome_buffered('你'))
        __M_writer('\n\n')
        return ''
    finally:
        context.caller_stack._pop_frame()


def render_welcome_buffered(context,who,place='\xe5\x8c\x97\xe4\xba\xac'):
    __M_caller = context.caller_stack._push_frame()
    try:
        context._push_buffer()
        __M_writer = context.writer()
        __M_writer('\nWelcome ')
        __M_writer(who)
        __M_writer(' to ')
        __M_writer(place)
        __M_writer('.\n')
    finally:
        __M_buf = context._pop_buffer()
        context.caller_stack._pop_frame()
    return __M_buf.getvalue()


def render_welcome(context,who,place='\xe5\x8c\x97\xe4\xba\xac'):
    __M_caller = context.caller_stack._push_frame()
    try:
        __M_writer = context.writer()
        __M_writer('\nWelcome ')
        __M_writer(who)
        __M_writer(' to ')
        __M_writer(place)
        __M_writer('.\n')
        return ''
    finally:
        context.caller_stack._pop_frame()


"""
__M_BEGIN_METADATA
{"source_encoding": "utf-8", "line_map": {"15": 0, "25": 1, "26": 2, "27": 3, "28": 4, "31": 3, "32": 7, "33": 11, "34": 13, "35": 13, "36": 13, "37": 13, "38": 14, "39": 14, "40": 15, "41": 15, "47": 9, "52": 9, "53": 10, "54": 10, "55": 10, "56": 10, "63": 5, "67": 5, "68": 6, "69": 6, "70": 6, "71": 6, "77": 71}, "uri": "chs_utf8.html", "filename": "/home/vagrant/Desktop/a2/zzzeek-mako-12819efda61b/test/templates/chs_utf8.html"}
__M_END_METADATA
"""
